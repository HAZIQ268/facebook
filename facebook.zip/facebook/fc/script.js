

// feature slider

$(document).ready(function () {

    $(".modern-slider").slick({
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1,
                    adaptiveHeight: true,
                },
            },
            {
                breakpoint: 640,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1,
                },
            },
        ],
        autoplay: false,
        autoplaySpeed: 2000,
        speed: 330,
        slidesToShow: 2,
        slidesToScroll: 1,
        pauseOnHover: false,
        dots: false,
        pauseOnDotsHover: true,
        cssEase: 'linear',
        // fade:true,
        draggable: true,
        prevArrow: '<button class="prev-arrow"></button>',
        nextArrow: '<button class="next-arrow"></button>',
    });

    
  
  })

